#!/bin/bash

timeout 10 /bot.py $1
