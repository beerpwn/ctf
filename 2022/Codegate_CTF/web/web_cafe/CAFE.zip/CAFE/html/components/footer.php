    <script src="/static/js/jquery-3.4.1.min.js"></script>
    <script src="/static/bootstrap/js/bootstrap.min.js"></script>
    <script src="/static/js/popper.min.js"></script>
    <script src="/static/js/axios.min.js"></script>
</body>
</html>